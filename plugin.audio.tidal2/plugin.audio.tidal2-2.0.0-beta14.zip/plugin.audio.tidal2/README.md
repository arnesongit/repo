# plugin.audio.tidal-master

This is a modified version of the TIDAL Addon for Kodi.

See [changelog.txt](https://github.com/arnesongit/plugin.audio.tidal/blob/master/changelog.txt) for informations.

## Installation

1. Download the zip file [from this folder](https://github.com/arnesongit/repo/tree/master/plugin.audio.tidal2) from github
2. Use "Install from Zip" Method to install the addon.
3. The Addon is shown as "TIDAL2"
4. Have fun.
