# plugin.audio.tidal-master

This is a modified version of the TIDAL Addon for Kodi.

See [changelog.txt](https://github.com/arnesongit/plugin.audio.tidal/blob/master/changelog.txt) for informations.

## Installation

1. Download this [Zip-File](https://github.com/arnesongit/plugin.audio.tidal/archive/master.zip) from github
2. Use "Install from Zip" Method to install the addon.
3. The Addon is shown as "TIDAL2"
4. Have fun.
