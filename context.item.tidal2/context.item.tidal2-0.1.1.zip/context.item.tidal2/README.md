# context.item.tidal-search

This is a Kodi Context Menu Addon to search for TIDAL content.

This Addon requires my Kodi TIDAL2 Addon [plugin.audio.tidal2](https://github.com/arnesongit/python-tidal2)

See [changelog.txt](https://github.com/arnesongit/context.item.tidal2/blob/master/changelog.txt) for informations.

## Installation

1. Download the zip file [from this folder](https://github.com/arnesongit/repo/tree/master/context.item.tidal2) from github
2. Use "Install from Zip" Method to install the addon.
3. The Addon appears in the Context Menu as "TIDAL2 ..."
4. Have fun.
