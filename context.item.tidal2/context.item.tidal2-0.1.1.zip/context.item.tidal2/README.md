# context.item.tidal-search

This is a Kodi Context Menu Addon to search for TIDAL content.

This Addon requires my Kodi TIDAL Addon [plugin.audio.tidal-master](https://github.com/arnesongit/python-tidal)

See [changelog.txt](https://github.com/arnesongit/context.item.tidal/blob/search/changelog.txt) for informations.

## Installation

1. Download this [Zip-File](https://github.com/arnesongit/context.item.tidal/archive/search.zip) from github
2. Use "Install from Zip" Method to install the addon.
3. The Addon appears in the Context Menu as "TIDAL ..."
4. Have fun.
